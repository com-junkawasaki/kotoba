//! kotoba-web - Kotoba Web Components

pub mod prelude {
    // Re-export commonly used items
}

#[cfg(test)]
mod tests {
    // Tests will be added here
}
