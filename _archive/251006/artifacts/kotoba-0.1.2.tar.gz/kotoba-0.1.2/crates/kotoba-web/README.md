# Kotoba Web

Web framework and HTTP components for Kotoba.

Provides HTTP server and frontend integration.

## License

MIT OR Apache-2.0