# Kotoba Core

Core components for Kotoba graph processing system.

Provides fundamental types and IR definitions.

## License

MIT OR Apache-2.0