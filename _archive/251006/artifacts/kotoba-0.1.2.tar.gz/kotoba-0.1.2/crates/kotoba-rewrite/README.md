# Kotoba Rewrite

Graph rewriting engine for Kotoba.

Implements DPO (Double Pushout) graph transformations.

## License

MIT OR Apache-2.0