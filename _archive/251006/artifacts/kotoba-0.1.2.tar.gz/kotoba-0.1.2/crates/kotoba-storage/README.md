# Kotoba Storage

Storage layer for Kotoba with MVCC and Merkle DAG.

Provides persistent storage with versioning.

## License

MIT OR Apache-2.0