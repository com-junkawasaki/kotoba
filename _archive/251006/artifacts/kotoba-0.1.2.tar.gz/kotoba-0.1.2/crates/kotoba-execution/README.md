# Kotoba Execution

Query execution and planning for Kotoba.

Includes GQL parser, logical planner, and physical execution.

## License

MIT OR Apache-2.0