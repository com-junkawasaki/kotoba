# Kotoba Graph

Graph data structures and operations for Kotoba.

Includes vertex, edge, and graph implementations.

## License

MIT OR Apache-2.0