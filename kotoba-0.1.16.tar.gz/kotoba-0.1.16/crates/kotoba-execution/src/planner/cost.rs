use kotoba_core::types::Result;
use kotoba_errors::KotobaError;

/// Cost model for query optimization
pub struct CostModel;
