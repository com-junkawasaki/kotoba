//! In-memory storage backend for testing and development.
