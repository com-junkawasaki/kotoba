//! ユースケース実装例

pub mod social_network;
